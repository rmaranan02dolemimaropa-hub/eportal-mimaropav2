/* =============================================================
   DOLE MIMAROPA E-PORTAL — LOGIN PAGE SCRIPT
   Plain vanilla JavaScript only (no frameworks/libraries).
   Handles:
     1. Show / hide password toggle
     2. Sign-in button loading spinner example
============================================================= */

document.addEventListener('DOMContentLoaded', function () {

  /* -----------------------------------------------------------
     1. SHOW / HIDE PASSWORD TOGGLE
  ----------------------------------------------------------- */
  const passwordInput = document.getElementById('password');
  const toggleBtn = document.getElementById('togglePassword');
  const toggleIcon = document.getElementById('toggleIcon');

  if (toggleBtn && passwordInput && toggleIcon) {
    toggleBtn.addEventListener('click', function () {
      const isHidden = passwordInput.type === 'password';

      passwordInput.type = isHidden ? 'text' : 'password';

      // Swap icon between "eye" and "eye-slash"
      toggleIcon.classList.toggle('bi-eye-fill', !isHidden);
      toggleIcon.classList.toggle('bi-eye-slash-fill', isHidden);

      // Update accessibility state
      toggleBtn.setAttribute('aria-pressed', String(isHidden));
      toggleBtn.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
    });
  }

  /* -----------------------------------------------------------
     2. SIGN-IN BUTTON — LOADING SPINNER EXAMPLE
     NOTE: This is a front-end demo only. Replace this handler
     with real authentication logic when wiring up a backend.
  ----------------------------------------------------------- */
  const loginForm = document.getElementById('loginForm');
  const signInBtn = document.getElementById('signInBtn');

  if (loginForm && signInBtn) {
    const btnLabel = signInBtn.querySelector('.btn-label');
    const btnSpinner = signInBtn.querySelector('.btn-spinner');

    loginForm.addEventListener('submit', function (event) {
      event.preventDefault();

      // Basic native validation before "submitting"
      if (!loginForm.checkValidity()) {
        loginForm.reportValidity();
        return;
      }

      // Switch button into loading state
      signInBtn.disabled = true;
      btnLabel.classList.add('d-none');
      btnSpinner.classList.remove('d-none');

      // Simulate an authentication request.
      // In production, replace this timeout with a real fetch/AJAX call
      // and redirect or show errors based on the actual server response.
      window.setTimeout(function () {
        signInBtn.disabled = false;
        btnLabel.classList.remove('d-none');
        btnSpinner.classList.add('d-none');
      }, 1800);
    });
  }
});
